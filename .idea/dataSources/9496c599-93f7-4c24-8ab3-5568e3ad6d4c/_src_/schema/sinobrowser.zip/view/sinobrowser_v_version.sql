CREATE VIEW sinobrowser_v_version AS
  SELECT
    `sinobrowser`.`sinobrowser_install_config`.`version`     AS `version`,
    `sinobrowser`.`sinobrowser_install_config`.`create_time` AS `create_time`
  FROM `sinobrowser`.`sinobrowser_install_config`
  WHERE (`sinobrowser`.`sinobrowser_install_config`.`DELETE_FLAG` = 0)
  UNION ALL SELECT
              `info`.`version`     AS `version`,
              `info`.`CREATE_TIME` AS `create_time`
            FROM `sinobrowser`.`sinobrowser_version_info` `info`
            WHERE (`info`.`DELETE_FLAG` = 0);
